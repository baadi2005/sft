#!/bin/bash

# Check if script is run as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root"
   exit 1
fi

echo "Re-enabling USB storage devices (pendrives)..."

# Step 1: Remove the udev rule that blocks USB storage
UDEV_RULE="/etc/udev/rules.d/99-disable-usb-storage.rules"
if [[ -f "$UDEV_RULE" ]]; then
    rm "$UDEV_RULE"
    echo "Removed udev rule: $UDEV_RULE"
else
    echo "No udev rule found at $UDEV_RULE"
fi

# Step 2: Remove the kernel module blacklist
BLACKLIST_FILE="/etc/modprobe.d/disable-usb-storage.conf"
if [[ -f "$BLACKLIST_FILE" ]]; then
    rm "$BLACKLIST_FILE"
    echo "Removed blacklist file: $BLACKLIST_FILE"
else
    echo "No blacklist file found at $BLACKLIST_FILE"
fi

# Step 3: Reload udev rules
udevadm control --reload-rules
udevadm trigger
echo "Reloaded udev rules"

# Step 4: Reload USB storage kernel modules
modprobe usb-storage 2>/dev/null
modprobe uas 2>/dev/null
echo "Reloaded usb-storage and uas kernel modules"

# Step 5: Re-authorize existing USB storage devices
for device in /sys/bus/usb/devices/*/authorized; do
    if [[ -f "$device" ]]; then
        # Check if the device is a storage device
        dev_path=$(dirname "$device")
        if udevadm info --path="$dev_path" | grep -q 'ID_USB_DRIVER=usb-storage\|ID_USB_DRIVER=uas'; then
            echo 1 > "$device"
            echo "Re-authorized USB storage device: $dev_path"
        fi
    fi
done

# Step 6: Update initramfs to remove blacklist effects
update-initramfs -u
echo "Updated initramfs"

echo "USB storage devices (pendrives) re-enabled."
echo "Please test by plugging in a pendrive—it should be recognized."
