#!/bin/bash

# Check if script is run as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root"
   exit 1
fi

echo "Disabling USB storage devices (pendrives)..."

# Step 1: Unmount and unbind existing USB storage devices
usb_devices=$(lsblk -o NAME,TRAN,TYPE | grep 'usb.*disk' | awk '{print $1}')

if [[ -z "$usb_devices" ]]; then
    echo "No USB storage devices currently connected."
else
    for dev in $usb_devices; do
        dev_path="/dev/$dev"
        # Unmount if mounted
        mountpoint=$(lsblk -o MOUNTPOINT "/dev/$dev" | grep -v MOUNTPOINT | grep -v '^$')
        if [[ -n "$mountpoint" ]]; then
            umount "$mountpoint" 2>/dev/null
            echo "Unmounted $dev_path from $mountpoint"
        fi
        # Unbind driver
        sys_path=$(udevadm info --query path --name "$dev" | grep -o '/devices/.*disk')
        if [[ -n "$sys_path" ]]; then
            driver_path="/sys$sys_path/driver"
            if [[ -d "$driver_path" ]]; then
                dev_id=$(basename "$sys_path")
                echo "$dev_id" > "$driver_path/unbind" 2>/dev/null
                echo "Unbound USB storage device: $dev_path"
            fi
        fi
    done
fi

# Step 2: Unload and blacklist USB storage kernel modules
modprobe -r usb-storage 2>/dev/null
modprobe -r uas 2>/dev/null
echo 'blacklist usb-storage' > /etc/modprobe.d/disable-usb-storage.conf
echo 'blacklist uas' >> /etc/modprobe.d/disable-usb-storage.conf

# Step 3: Create a stricter udev rule to block USB storage
UDEV_RULE="/etc/udev/rules.d/99-disable-usb-storage.rules"
cat > "$UDEV_RULE" << 'EOF'
# Block all USB mass storage devices
SUBSYSTEM=="block", KERNEL=="sd[a-z]*", ENV{ID_USB_DRIVER}=="usb-storage", RUN+="/bin/sh -c 'echo 0 > /sys$env{DEVPATH}/../authorized'"
SUBSYSTEM=="block", KERNEL=="sd[a-z]*", ENV{ID_USB_DRIVER}=="uas", RUN+="/bin/sh -c 'echo 0 > /sys$env{DEVPATH}/../authorized'"
EOF

# Step 4: Reload udev rules and trigger
udevadm control --reload-rules
udevadm trigger

# Step 5: Update initramfs to ensure blacklist persists
update-initramfs -u

echo "USB storage devices (pendrives) disabled. Mouse, keyboard, etc., should remain functional."
echo "Please test by plugging in a pendrive—it should not be recognized."
