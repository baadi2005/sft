#!/bin/bash

PASSWORD="comp@pccoer25"
ENABLE_SCRIPT="./enable_usb.sh"
DISABLE_SCRIPT="./disable_usb.sh"

# Must be run as root
if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root (use sudo)"
   exit 1
fi

# Ensure both scripts are executable
chmod +x "$ENABLE_SCRIPT" "$DISABLE_SCRIPT"

if [[ "$1" == "enable" ]]; then
    echo -n "Enter password to enable USB: "
    read -s input
    echo
    if [[ "$input" == "$PASSWORD" ]]; then
        echo "Password correct. Enabling USB..."
        sudo "$ENABLE_SCRIPT"
    else
        echo "Incorrect password. Access denied."
        exit 1
    fi
else
    echo "Disabling USB..."
    sudo "$DISABLE_SCRIPT"
fi
